import 'package:flutter/material.dart';

import 'banco_de_dados/sql_helper.dart';

class DecksScreen extends StatefulWidget {
  const DecksScreen({super.key});

  @override
  State<DecksScreen> createState() => _DecksScreenState();
}

class _DecksScreenState extends State<DecksScreen> {
  int? selectedDeckId;

  List<Map<String, dynamic>> decks = [];
  bool isLoading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    _loadDecks();
  }

  // READ: buscar os decks no SQLite
  Future<void> _loadDecks() async {
    if (mounted) {
      setState(() {
        isLoading = true;
        errorMessage = null;
      });
    }

    try {
      final result = await SQLHelper.pegaDecks();

      if (!mounted) return;

      setState(() {
        decks = result;
        isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
        errorMessage = 'Erro ao carregar decks: $e';
      });
    }
  }

  // Abrir criação e atualizar a lista ao voltar
  Future<void> _openCreateDeck() async {
    await Navigator.pushNamed(context, '/create-deck');

    if (!mounted) return;

    await _loadDecks();
  }

  // Abrir os detalhes do deck
  Future<void> _openDeckDetails(int deckId) async {
    setState(() {
      selectedDeckId = deckId;
    });

    await Navigator.pushNamed(context, '/deck-details', arguments: deckId);

    if (!mounted) return;

    await _loadDecks();
  }

  // Exibir erro ou aviso
  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 2)),
    );
  }

  @override
  Widget build(BuildContext context) {
    const primaryPurple = Color(0xFF6C5CE7);

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FE),
      body: SafeArea(
        child: Column(
          children: [
            // Cabeçalho original
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 16, 24, 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      IconButton(
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                        icon: const Icon(
                          Icons.arrow_back,
                          color: Colors.black,
                          size: 24,
                        ),
                        onPressed: () => Navigator.pop(context),
                      ),
                      const SizedBox(width: 16),
                      const Text(
                        'Meus decks',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                  IconButton(
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    icon: const Icon(
                      Icons.search,
                      color: Colors.black,
                      size: 26,
                    ),
                    onPressed: () {
                      _showMessage('Pesquisa em desenvolvimento');
                    },
                  ),
                ],
              ),
            ),

            Expanded(
              child: RefreshIndicator(
                onRefresh: _loadDecks,
                child: SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(
                    parent: BouncingScrollPhysics(),
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 12,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Seus materiais de estudo',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Organize seus flashcards por matérias.',
                        style: TextStyle(fontSize: 14, color: Colors.grey),
                      ),
                      const SizedBox(height: 20),

                      // Lista dinâmica do SQLite
                      if (isLoading)
                        const Center(
                          child: Padding(
                            padding: EdgeInsets.all(32),
                            child: CircularProgressIndicator(
                              color: primaryPurple,
                            ),
                          ),
                        )
                      else if (errorMessage != null)
                        Center(
                          child: Column(
                            children: [
                              Text(
                                errorMessage!,
                                textAlign: TextAlign.center,
                                style: const TextStyle(color: Colors.red),
                              ),
                              TextButton(
                                onPressed: _loadDecks,
                                child: const Text('Tentar novamente'),
                              ),
                            ],
                          ),
                        )
                      else if (decks.isEmpty)
                        _buildEmptyState()
                      else
                        ...decks.map((deck) {
                          final id = deck['id'] as int;
                          final title = deck['title']?.toString() ?? 'Sem nome';

                          final count =
                              (deck['cards_count'] as num?)?.toInt() ?? 0;

                          return _buildDeckItem(
                            id: id,
                            title: title,
                            cardsCount:
                                '$count ${count == 1 ? 'card' : 'cards'}',
                            onTap: () => _openDeckDetails(id),
                          );
                        }),

                      const SizedBox(height: 20),

                      // Botão original
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: primaryPurple,
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                          ),
                          onPressed: _openCreateDeck,
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.add, color: Colors.white, size: 20),
                              SizedBox(width: 8),
                              Text(
                                'Criar novo deck',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                    ],
                  ),
                ),
              ),
            ),

            // Barra inferior original
            Container(
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: const BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10,
                    offset: Offset(0, -2),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  InkWell(
                    onTap: () =>
                        Navigator.pushReplacementNamed(context, '/home'),
                    child: _buildNavItem(Icons.home_outlined, 'Início'),
                  ),
                  _buildNavItem(Icons.style, 'Decks', active: true),
                  GestureDetector(
                    onTap: () =>
                        Navigator.pushNamed(context, '/create-flashcards'),
                    child: Container(
                      width: 54,
                      height: 54,
                      decoration: const BoxDecoration(
                        color: primaryPurple,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.add,
                        color: Colors.white,
                        size: 28,
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: () =>
                        Navigator.pushReplacementNamed(context, '/progress'),
                    child: _buildNavItem(Icons.bar_chart_outlined, 'Progresso'),
                  ),
                  InkWell(
                    onTap: () =>
                        Navigator.pushReplacementNamed(context, '/profile'),
                    child: _buildNavItem(Icons.person_outline, 'Perfil'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Mensagem quando não há decks
  Widget _buildEmptyState() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: const Column(
        children: [
          Icon(Icons.style_outlined, size: 52, color: Color(0xFF6C5CE7)),
          SizedBox(height: 16),
          Text(
            'Nenhum deck criado ainda',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Crie seu primeiro deck para organizar seus estudos.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 14, color: Colors.grey),
          ),
        ],
      ),
    );
  }

  // Card com a estética original
  Widget _buildDeckItem({
    required int id,
    required String title,
    required String cardsCount,
    VoidCallback? onTap,
  }) {
    final bool isSelected = selectedDeckId == id;

    return GestureDetector(
      onTap: () {
        setState(() {
          selectedDeckId = isSelected ? null : id;
        });

        onTap?.call();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFFF3F0FF) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? const Color(0xFF6C5CE7) : Colors.transparent,
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: isSelected
                  ? const Color(0xFF6C5CE7).withValues(alpha: 0.15)
                  : Colors.black.withValues(alpha: 0.02),
              blurRadius: isSelected ? 12 : 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: isSelected
                          ? const Color(0xFF6C5CE7)
                          : Colors.black,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    cardsCount,
                    style: const TextStyle(fontSize: 13, color: Colors.grey),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.chevron_right,
              color: isSelected ? const Color(0xFF6C5CE7) : Colors.black54,
              size: 22,
            ),
          ],
        ),
      ),
    );
  }

  // Ícones da navegação inferior
  Widget _buildNavItem(IconData icon, String label, {bool active = false}) {
    final color = active ? const Color(0xFF6C5CE7) : Colors.grey;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: color, size: 24),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: color,
            fontSize: 11,
            fontWeight: active ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ],
    );
  }
}
